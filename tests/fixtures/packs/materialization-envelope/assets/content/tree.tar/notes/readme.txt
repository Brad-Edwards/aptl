Synthetic directory content owned by the APTL test suite.
